const enc = new TextEncoder();
function b64url(bytes) { return btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,''); }
async function sign(value, secret) {
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), {name:'HMAC',hash:'SHA-256'}, false, ['sign']);
  return b64url(await crypto.subtle.sign('HMAC', key, enc.encode(value)));
}
export async function validAdmin(request, env) {
  const token = (request.headers.get('Cookie') || '').split(';').map(x=>x.trim()).find(x=>x.startsWith('jboy_admin='));
  if (!token || !env.SESSION_SECRET) return false;
  const value = token.slice('jboy_admin='.length);
  const [payload, sig] = value.split('.');
  if (!payload || !sig) return false;
  const expected = await sign(payload, env.SESSION_SECRET);
  if (sig !== expected) return false;
  try { const data=JSON.parse(atob(payload.replace(/-/g,'+').replace(/_/g,'/'))); return data.exp>Date.now(); } catch { return false; }
}
export async function makeSession(env) {
  const payload=b64url(enc.encode(JSON.stringify({exp:Date.now()+8*60*60*1000,role:'admin'})));
  return `${payload}.${await sign(payload,env.SESSION_SECRET)}`;
}
export function json(data,status=200,headers={}) {
  return new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers}});
}
