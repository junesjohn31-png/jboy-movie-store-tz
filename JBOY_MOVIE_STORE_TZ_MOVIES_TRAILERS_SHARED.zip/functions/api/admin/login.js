import { makeSession, json } from '../../_shared/auth.js';
export async function onRequestPost({request,env}) {
  if (!env.ADMIN_PASSWORD || !env.SESSION_SECRET) return json({error:'Admin secrets hazijawekwa Cloudflare.'},503);
  let body; try { body=await request.json(); } catch { return json({error:'Ombi si sahihi.'},400); }
  if (body.password !== env.ADMIN_PASSWORD) return json({error:'Password si sahihi.'},401);
  const token=await makeSession(env);
  return json({ok:true},200,{ 'Set-Cookie':`jboy_admin=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=28800` });
}
