import { validAdmin, json } from '../_shared/auth.js';
export async function onRequestGet({env}) {
  if (!env.DB) return json({error:'D1 database haijaunganishwa.'},503);
  const {results=[]}=await env.DB.prepare('SELECT id,title,type,price,description,poster_url AS poster,video_url AS video,trailer_url AS trailer FROM movies ORDER BY created_at DESC').all();
  return json(results);
}
export async function onRequestPost({request,env}) {
  if (!(await validAdmin(request,env))) return json({error:'Ingia kama admin kwanza.'},401);
  if (!env.DB || !env.MOVIES_BUCKET) return json({error:'Cloudflare D1 au R2 binding haijaunganishwa.'},503);
  const form=await request.formData();
  const title=String(form.get('title')||'').trim(), type=String(form.get('type')||'movie');
  const price=Math.max(0,Number(form.get('price')||0)), description=String(form.get('desc')||'');
  const poster=form.get('poster'), video=form.get('video'), trailer=form.get('trailer');
  const trailerUrl=String(form.get('trailerUrl')||'').trim();
  if (!title || !poster || typeof poster==='string' || !poster.type.startsWith('image/')) return json({error:'Jina na picha halali ya cover vinahitajika.'},400);
  if (poster.size>10*1024*1024) return json({error:'Cover lisizidi 10MB.'},413);
  for (const [label,file] of [['Movie',video],['Trailer',trailer]]) if(file && typeof file!=='string' && file.size>90*1024*1024) return json({error:`${label} imezidi 90MB. Tumia video hosting/CDN au upload ya vipande.`},413);
  if (trailerUrl && !/^https:\/\//i.test(trailerUrl)) return json({error:'Trailer URL lazima ianze na https://'},400);
  const id=crypto.randomUUID(), safe=n=>n.replace(/[^a-zA-Z0-9._-]/g,'_');
  const pkey=`posters/${id}-${safe(poster.name||'cover')}`;
  let vkey=null,tkey=null;
  await env.MOVIES_BUCKET.put(pkey,poster.stream(),{httpMetadata:{contentType:poster.type}});
  try {
    if(video && typeof video!=='string' && video.size){vkey=`videos/${id}-${safe(video.name||'movie.mp4')}`;await env.MOVIES_BUCKET.put(vkey,video.stream(),{httpMetadata:{contentType:video.type||'video/mp4'}});}
    if(trailer && typeof trailer!=='string' && trailer.size){tkey=`trailers/${id}-${safe(trailer.name||'trailer.mp4')}`;await env.MOVIES_BUCKET.put(tkey,trailer.stream(),{httpMetadata:{contentType:trailer.type||'video/mp4'}});}
    const origin=new URL(request.url).origin, posterUrl=`${origin}/media/${pkey}`;
    const videoUrl=vkey?`${origin}/media/${vkey}`:null, trailerFinal=tkey?`${origin}/media/${tkey}`:(trailerUrl||null);
    await env.DB.prepare('INSERT INTO movies (id,title,type,price,description,poster_key,video_key,trailer_key,poster_url,video_url,trailer_url) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
      .bind(id,title,type,price,description,pkey,vkey,tkey,posterUrl,videoUrl,trailerFinal).run();
    return json({ok:true,id,title,poster:posterUrl,video:videoUrl,trailer:trailerFinal},201);
  } catch(e) { await env.MOVIES_BUCKET.delete(pkey);if(vkey)await env.MOVIES_BUCKET.delete(vkey);if(tkey)await env.MOVIES_BUCKET.delete(tkey);throw e; }
}
export async function onRequestDelete({request,env}) {
  if (!(await validAdmin(request,env))) return json({error:'Ingia kama admin kwanza.'},401);
  if (!env.DB || !env.MOVIES_BUCKET) return json({error:'D1 au R2 haijaunganishwa.'},503);
  const id=new URL(request.url).searchParams.get('id'); if(!id)return json({error:'Movie ID inahitajika.'},400);
  const row=await env.DB.prepare('SELECT poster_key,video_key,trailer_key FROM movies WHERE id=?').bind(id).first();
  if(!row)return json({error:'Movie haijapatikana.'},404);
  await env.DB.prepare('DELETE FROM movies WHERE id=?').bind(id).run();
  for(const key of [row.poster_key,row.video_key,row.trailer_key])if(key)await env.MOVIES_BUCKET.delete(key);
  return json({ok:true});
}
