export async function onRequest({params,env}) {
  const key=Array.isArray(params.key)?params.key.join('/'):String(params.key||'');
  if (!key || key.includes('..') || !env.MOVIES_BUCKET) return new Response('Not found',{status:404});
  const obj=await env.MOVIES_BUCKET.get(key);
  if (!obj) return new Response('Not found',{status:404});
  const headers=new Headers();
  obj.writeHttpMetadata(headers);
  headers.set('etag',obj.httpEtag);
  headers.set('Cache-Control','public, max-age=86400');
  return new Response(obj.body,{headers});
}
